package com.example.nshwe.sharedpreferrncesloginapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    EditText user,pswd;
    CheckBox rememberMe;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        user = findViewById(R.id.edUser);
        pswd = findViewById(R.id.edPswd);
        rememberMe = findViewById(R.id.checkBox);
        button = findViewById(R.id.button);

        sharedPreferences = getSharedPreferences("myData2", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        button.setOnClickListener((v) -> {
            login();
        });
        forNextLogin();
    }

    private void forNextLogin() {
        if(sharedPreferences.getBoolean("saveLogin",false)) {
            //Setting Credentials to the login page
            /*user.setText(sharedPreferences.getString("user",null));
            pswd.setText(sharedPreferences.getString("pswd",null));*/
            //Moving to main Screen directly
                nextActivity();
        }
    }

    private void login() {
        String usr = user.getText().toString();
        String psd = pswd.getText().toString();

        if(rememberMe.isChecked()){
            saveCredentials(usr,psd);
        }
        if(usr.equals("iam") && psd.equals("iamnot")){
            nextActivity();
        }
    }

    private void nextActivity() {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

    private void saveCredentials(String usr, String psd) {
        editor.putBoolean("saveLogin",true);
        editor.putString("user",usr);
        editor.putString("pswd",psd);
        editor.commit();
    }
}
