package com.example.nshwe.filehandlingapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class WriteActivity extends AppCompatActivity implements View.OnClickListener {

    EditText writeEd;
    Button write,next;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write);

        writeEd = findViewById(R.id.readEd);

        write = findViewById(R.id.read);
        next = findViewById(R.id.next);

        write.setOnClickListener(this);
        next.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v == write)
            writeData();
        else{
            Intent intent = new Intent(this,ReadActivity.class);
            startActivity(intent);
        }
    }

    private void writeData(){

        try (FileOutputStream fileOutputStream = openFileOutput("MyData.txt", Context.MODE_APPEND);
             OutputStreamWriter streamWriter = new OutputStreamWriter(fileOutputStream)){

            File folder = getFilesDir();
            streamWriter.write(writeEd.getText().toString());
            streamWriter.flush();

            Log.d("File Stored in : ",folder.toString());
            Toast.makeText(this,"File Stored in : "+folder.toString(),Toast.LENGTH_LONG).show();

        }catch (IOException e) {
            e.printStackTrace();
        }
    }
}
