package com.example.nshwe.filehandlingapp;

import android.os.Environment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class DiffMemoryActivity extends AppCompatActivity implements View.OnClickListener{

    EditText editText;
    Button inCache,exCache,prExternal,puExternal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diff_memory);

        editText = findViewById(R.id.editText2);
        inCache = findViewById(R.id.internalCache);
        exCache = findViewById(R.id.externalcache);
        prExternal = findViewById(R.id.externalPrivate);
        puExternal = findViewById(R.id.externalPublic);

        inCache.setOnClickListener(this);
        exCache.setOnClickListener(this);
        prExternal.setOnClickListener(this);
        puExternal.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v == inCache)
            saveInternalCache();
        else if(v == exCache)
            saveExternalCache();
        else if(v == prExternal)
            saveExternalPrivate();
        else
            saveExternalPublic();
    }

    private void writeData(File folder){
        try (FileOutputStream fileOutputStream = new FileOutputStream(folder);
             OutputStreamWriter streamWriter = new OutputStreamWriter(fileOutputStream)){

            streamWriter.write(editText.getText().toString());
            streamWriter.flush();
            display("Data Stored Successfully in "+folder);

        }catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void display(String s) {
        Toast.makeText(this,s,Toast.LENGTH_LONG).show();
        new AlertDialog.Builder(this)
                .setMessage(s)
                .setCancelable(true)
                .show();
    }

    private void saveExternalPublic() {
        File folder = Environment.getExternalStorageDirectory();
        File file = new File(folder,"MyData4.txt");
        writeData(file);
    }
    private void saveExternalPrivate() {
        File folder = getExternalFilesDir("MyDir");
        File file = new File(folder,"MyData3.txt");
        writeData(file);
    }
    private void saveExternalCache() {
        File folder = getExternalCacheDir();
        File file = new File(folder,"MyData2.txt");
        writeData(file);
    }
    private void saveInternalCache() {
       // Toast.makeText(this,"MyDebug",Toast.LENGTH_LONG).show();
        File folder = getCacheDir();
        File file = new File(folder,"MyData1.txt");
        writeData(file);
    }
}
