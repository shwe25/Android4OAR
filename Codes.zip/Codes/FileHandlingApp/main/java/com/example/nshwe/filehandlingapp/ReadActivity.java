package com.example.nshwe.filehandlingapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class ReadActivity extends AppCompatActivity implements View.OnClickListener {

    EditText readEd;
    Button read, next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read);

        readEd = findViewById(R.id.readEd);
        read = findViewById(R.id.read);
        next = findViewById(R.id.next2);

        read.setOnClickListener(this);
        next.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == read)
            readData();
        else {
            Intent intent = new Intent(this, DiffMemoryActivity.class);
            startActivity(intent);
        }
    }

    private void readData() {
        try (FileInputStream fileInputStream = openFileInput("MyData.txt");
             InputStreamReader streamReader = new InputStreamReader(fileInputStream)) {

            char[] ch = new char[50];
            String data = "";
            int readCh = 0;
            while ((readCh = streamReader.read(ch)) > 0){
                data += String.copyValueOf(ch,0,readCh);
            }
            readEd.setText(data);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}