package com.example.nshwe.studentdbapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText idEt,nameEt,marksEt;
    private SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        idEt = findViewById(R.id.id);
        nameEt = findViewById(R.id.name);
        marksEt = findViewById(R.id.marks);

        sqLiteDatabase = openOrCreateDatabase("student_db", Context.MODE_PRIVATE,null);
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS student" +
                "(id VARCHAR,name VARCHAR,marks VARCHAR)");

    }

    public void add(View view){
        if(idEt.getText().toString().trim().length() == 0 ||
               nameEt.getText().toString().trim().length() == 0 ||
                marksEt.getText().toString().trim().length() == 0)
            display("Error","All the Fields are mandatory");
        else{
            ContentValues contentValues = new ContentValues();
            contentValues.put("id",idEt.getText().toString());
            contentValues.put("name",nameEt.getText().toString());
            contentValues.put("marks",marksEt.getText().toString());
            sqLiteDatabase.insert("student",null,contentValues);
            display("Success","1 row inserted");
            clearFields();
        }
    }
    public void view1(View view){
        if(idEt.getText().toString().trim().length() == 0)
            display("Error","Enter Id");
        else{
            Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM student WHERE id='"
                    +idEt.getText().toString()+"'",null);
            if(cursor.moveToNext()){
                StringBuilder builder = new StringBuilder("Record");
                builder.append("\nID : "+cursor.getString(0));
                builder.append("\nName : "+cursor.getString(1));
                builder.append("\nMarks : "+cursor.getString(2));
                display("Success",builder.toString());
            }else
                display("Error","Record not found");
        }
        clearFields();
    }
    public void update(View view){
        if(idEt.getText().toString().trim().length() == 0 ||
                nameEt.getText().toString().trim().length() == 0 ||
                marksEt.getText().toString().trim().length() == 0)
            display("Error","Enter Id, name & marks");
        else{
            ContentValues values = new ContentValues();
            values.put("name",nameEt.getText().toString());
            values.put("marks",marksEt.getText().toString());
            int result = sqLiteDatabase.update("student",values,
                    "id='"+idEt.getText().toString()+"'",null);

            if(result > 0)
                display("Success","1 row updated");
            else
                display("Error","no row updated");
            clearFields();
        }
    }
    public void delete(View view){
        if(idEt.getText().toString().trim().length() == 0)
            display("Error","Enter Id to delete record");
        else{
            int result = sqLiteDatabase.delete("student",
                    "id='"+idEt.getText().toString()+"'",null);
            if(result > 0)
                display("Success","1 row deleted");
            else
                display("Error","no row deleted");
            clearFields();
        }
    }
    public void viewAll(View view){
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM student",null);
        StringBuilder builder = new StringBuilder("Record");
        while(cursor.moveToNext()){
            builder.append("\n---------------------------");
            builder.append("\nID : "+cursor.getString(0));
            builder.append("\nName : "+cursor.getString(1));
            builder.append("\nMarks : "+cursor.getString(2));
            display("Success",builder.toString());
        }
    }

    private void display(String title, String msg) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(msg)
                .setCancelable(true)
                .show();
    }
    private void clearFields() {
        idEt.setText("");
        nameEt.setText("");
        marksEt.setText("");
    }
}
