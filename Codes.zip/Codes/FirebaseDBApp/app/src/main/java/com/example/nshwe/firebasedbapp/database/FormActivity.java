package com.example.nshwe.firebasedbapp.database;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.nshwe.firebasedbapp.MainActivity;
import com.example.nshwe.firebasedbapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FormActivity extends AppCompatActivity {

    private EditText name_et,contact_et,mail_et,yop_et;
    private Spinner qualification;
    private Button saveBtn;
    private DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        databaseReference = FirebaseDatabase.getInstance().getReference("student");

        name_et = findViewById(R.id.form_name);
        contact_et = findViewById(R.id.form_contact);
        mail_et = findViewById(R.id.form_mail);
        yop_et = findViewById(R.id.form_yop);
        qualification = findViewById(R.id.form_edu_details);
        saveBtn = findViewById(R.id.form_save_btn);

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addStudent();
            }
        });
    }

    private void addStudent() {
        String name = name_et.getText().toString().trim();
        String contact = contact_et.getText().toString().trim();
        String edu = qualification.getSelectedItem().toString();
        String yop = yop_et.getText().toString();
        String mail = mail_et.getText().toString();
        if(!TextUtils.isEmpty(name)){
            String id = databaseReference.push().getKey();

            Student student = new Student(id,name,contact,edu,yop,mail);

            databaseReference.child(id).setValue(student);

            startActivity(new Intent(this, MainActivity.class));
            finish();
        }else
            Toast.makeText(this,"You should enter name",Toast.LENGTH_SHORT).show();
    }
}
