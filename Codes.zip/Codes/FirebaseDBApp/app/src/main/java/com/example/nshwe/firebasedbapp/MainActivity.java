package com.example.nshwe.firebasedbapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.example.nshwe.firebasedbapp.database.FormActivity;
import com.example.nshwe.firebasedbapp.database.RecyclerListAdapter;
import com.example.nshwe.firebasedbapp.database.Student;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DatabaseReference studentReference;
    private RecyclerView recyclerView;
    private List<Student> students;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        studentReference = FirebaseDatabase.getInstance().getReference("student");

        recyclerView = findViewById(R.id.recyclerview);
        students = new ArrayList<>();

    }

    @Override
    protected void onStart() {
        super.onStart();
        studentReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                students.clear();
                for(DataSnapshot studentSnapshot : dataSnapshot.getChildren()){
                    Student student = studentSnapshot.getValue(Student.class);
                    students.add(student);
                }
                RecyclerListAdapter adapter = new RecyclerListAdapter(students,MainActivity.this);
                recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.mymenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.insert)
            startActivity(new Intent(this, FormActivity.class));
        if(item.getItemId() == R.id.delete)
            deleteStudent();
        if(item.getItemId() == R.id.update)
            updateStudent();
        return super.onOptionsItemSelected(item);
    }

    private void updateStudent() {
    }

    private void deleteStudent() {
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        moveTaskToBack(false);
    }
}
