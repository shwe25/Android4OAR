package com.example.nshwe.firebasedbapp;

import android.app.Application;
import android.os.SystemClock;

/**
 * Created by nshwe on 21-03-2018.
 */

public class MyApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        SystemClock.sleep(1000);
    }
}
