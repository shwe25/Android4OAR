package com.example.nshwe.firebasedbapp.database;

/**
 * Created by nshwe on 28-03-2018.
 */

public class Student {
    private String id;
    private String name;
    private String number;
    private String edu;
    private String yop;
    private String mailId;

    public Student(){}

    public Student(String id,String name, String number, String edu, String  yop, String mailId) {
        this.id = id;
        this.name = name;
        this.number = number;
        this.edu = edu;
        this.yop = yop;
        this.mailId = mailId;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getNumber() {
        return number;
    }

    public String getEdu() {
        return edu;
    }

    public String getYop() {
        return yop;
    }

    public String getMailId() {
        return mailId;
    }
}
