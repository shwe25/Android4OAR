package com.example.nshwe.firebasedbapp.database;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.nshwe.firebasedbapp.R;

import java.util.List;

/**
 * Created by nshwe on 28-03-2018.
 */

public class RecyclerListAdapter extends RecyclerView.Adapter<RecyclerListAdapter.MyViewHolder>{

    private Dialog dialog;
    private List<Student> students;
    private Context context;

    public RecyclerListAdapter(List<Student> students, Context context) {
        this.students = students;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, final int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_contents,parent,false);
        final MyViewHolder viewHolder = new MyViewHolder(view);

        dialog = new Dialog(context);
        dialog.setContentView(R.layout.dialog_content);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        viewHolder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView name = dialog.findViewById(R.id.dialog_name);
                TextView number = dialog.findViewById(R.id.dialog_number);
                TextView mail = dialog.findViewById(R.id.dialog_mail);
                TextView yop = dialog.findViewById(R.id.dialog_yop);
                TextView edu = dialog.findViewById(R.id.dialog_edu);

                name.setText(students.get(viewHolder.getAdapterPosition()).getName());
                number.setText(students.get(viewHolder.getAdapterPosition()).getNumber());
                mail.setText(students.get(viewHolder.getAdapterPosition()).getMailId());
                yop.setText(students.get(viewHolder.getAdapterPosition()).getYop());
                edu.setText(students.get(viewHolder.getAdapterPosition()).getEdu());

                dialog.show();
            }
    });
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.name_tv.setText(students.get(position).getName());
        holder.contact_tv.setText(students.get(position).getNumber());
    }

    @Override
    public int getItemCount() {
        return students.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout linearLayout;
        private TextView name_tv,contact_tv;
        private CardView cardView;

        public MyViewHolder(View itemView) {
            super(itemView);
            linearLayout = itemView.findViewById(R.id.content_linearlayout);
            name_tv = itemView.findViewById(R.id.list_name);
            contact_tv = itemView.findViewById(R.id.list_contact);
            cardView = itemView.findViewById(R.id.cardview);
        }
    }

}
