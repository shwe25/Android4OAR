package com.example.nshwe.pageviewerfragmentapp.list;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.nshwe.pageviewerfragmentapp.R;

import java.util.List;

/**
 * Created by nshwe on 19-03-2018.
 */

public class RecyclerviewListAdapter extends RecyclerView.Adapter<RecyclerviewListAdapter.MyViewHolder> {

    private Dialog dialog;
    private List<ContactDTO> data;
    private Context context;

    public RecyclerviewListAdapter(List<ContactDTO> data, Context context) {
        this.data = data;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_content,parent,false);
        final MyViewHolder viewHolder = new MyViewHolder(view);
        dialog = new Dialog(context);
        dialog.setContentView(R.layout.dialog_contact);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        viewHolder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView d_name = dialog.findViewById(R.id.dialog_name);
                TextView d_phone = dialog.findViewById(R.id.dialog_phone);
                ImageView d_img = dialog.findViewById(R.id.dialog_img);

                d_name.setText(data.get(viewHolder.getAdapterPosition()).getName());
                d_phone.setText(data.get(viewHolder.getAdapterPosition()).getNumber());
                d_img.setImageResource(data.get(viewHolder.getAdapterPosition()).getImg());
                //Toast.makeText(context,"Test Check"+String.valueOf(viewHolder.getAdapterPosition()),Toast.LENGTH_LONG).show();
                dialog.show();
            }
        });
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.name.setText(data.get(position).getName());
        holder.number.setText(data.get(position).getNumber());
        holder.imageView.setImageResource(data.get(position).getImg());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        private LinearLayout linearLayout;
        private ImageView imageView;
        private TextView name,number;

        public MyViewHolder(View itemView) {
            super(itemView);
            linearLayout = itemView.findViewById(R.id.linearlayout);
            imageView = itemView.findViewById(R.id.item_img);
            name = itemView.findViewById(R.id.name_it);
            number = itemView.findViewById(R.id.num_it);

        }
    }
}
