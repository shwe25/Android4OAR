package com.example.nshwe.pageviewerfragmentapp;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


public class MyListFragment extends Fragment {

    private View view;
    private RecyclerView recyclerView;
    private List<ContactDTO> data;

    @Nullable
    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_mylist,container,false);
        recyclerView = view.findViewById(R.id.recyclerview);
        RecyclerviewAdapter adapter = new RecyclerviewAdapter(data,getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(adapter);
        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        data = new ArrayList<>();
        data.add(new ContactDTO("Abc","1235577687",R.mipmap.ic_launcher_round));
        data.add(new ContactDTO("Bcd","8767589007",R.drawable.circle));
        data.add(new ContactDTO("Cde","8283692098",R.drawable.round_ball));
        data.add(new ContactDTO("Def","8398700123",R.mipmap.ic_launcher_round));
        data.add(new ContactDTO("Efg","7836872398",R.drawable.circle));
        data.add(new ContactDTO("Fgh","9492840399",R.drawable.round_ball));
        data.add(new ContactDTO("Abc","1235577687",R.mipmap.ic_launcher_round));
        data.add(new ContactDTO("Bcd","8767589007",R.drawable.circle));
        data.add(new ContactDTO("Cde","8283692098",R.drawable.round_ball));
        data.add(new ContactDTO("Def","8398700123",R.mipmap.ic_launcher_round));
        data.add(new ContactDTO("Efg","7836872398",R.drawable.circle));
        data.add(new ContactDTO("Fgh","9492840399",R.drawable.round_ball));
        data.add(new ContactDTO("Abc","1235577687",R.mipmap.ic_launcher_round));
        data.add(new ContactDTO("Bcd","8767589007",R.drawable.circle));
        data.add(new ContactDTO("Cde","8283692098",R.drawable.round_ball));
        data.add(new ContactDTO("Def","8398700123",R.mipmap.ic_launcher_round));
        data.add(new ContactDTO("Efg","7836872398",R.drawable.circle));
        data.add(new ContactDTO("Fgh","9492840399",R.drawable.round_ball));

    }
}
